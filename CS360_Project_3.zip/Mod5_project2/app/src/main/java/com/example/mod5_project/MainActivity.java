package com.example.mod5_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.app.AlertDialog;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST = 100;

    private DatabaseHelper db;
    private ListView listViewWeights;
    private Button buttonAddWeight, buttonUpdateWeight, buttonDeleteWeight, buttonSetGoal;

    private ArrayList<String> weightList;
    private ArrayList<Integer> weightIds;
    private ArrayAdapter<String> adapter;
    private int selectedId = -1;

    private boolean smsAllowed = false;
    private String userPhoneNumber = "5551234567"; // placeholder for testing

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        listViewWeights = findViewById(R.id.listViewWeights);
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonUpdateWeight = findViewById(R.id.buttonUpdateWeight);
        buttonDeleteWeight = findViewById(R.id.buttonDeleteWeight);
        buttonSetGoal = findViewById(R.id.buttonSetGoal);

        weightList = new ArrayList<>();
        weightIds = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, weightList);
        listViewWeights.setAdapter(adapter);

        loadWeights();

        listViewWeights.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                selectedId = weightIds.get(position);
                Toast.makeText(MainActivity.this, "Selected entry ID: " + selectedId, Toast.LENGTH_SHORT).show();
            }
        });

        buttonAddWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAddWeightDialog();
            }
        });

        buttonUpdateWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedId == -1) {
                    Toast.makeText(MainActivity.this, "Select an entry to update", Toast.LENGTH_SHORT).show();
                } else {
                    showUpdateWeightDialog();
                }
            }
        });

        buttonDeleteWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedId == -1) {
                    Toast.makeText(MainActivity.this, "Select an entry to delete", Toast.LENGTH_SHORT).show();
                } else {
                    boolean deleted = db.deleteWeight(selectedId);
                    if (deleted) {
                        Toast.makeText(MainActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                        selectedId = -1;
                        loadWeights();
                    } else {
                        Toast.makeText(MainActivity.this, "Delete failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        buttonSetGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSetGoalDialog();
            }
        });

        // Ask for SMS permission at runtime
        requestSmsPermission();
    }

    private void loadWeights() {
        weightList.clear();
        weightIds.clear();

        Cursor cursor = db.getAllWeights();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_WEIGHT_ID));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_WEIGHT_VALUE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_WEIGHT_DATE));

                weightIds.add(id);
                weightList.add(date + " - " + weight + " lbs");
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void showAddWeightDialog() {
        final EditText input = new EditText(this);
        input.setHint("Enter weight");

        new AlertDialog.Builder(this)
                .setTitle("Add Daily Weight")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String text = input.getText().toString().trim();
                        if (text.isEmpty()) {
                            Toast.makeText(MainActivity.this, "Weight required", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        double weight = Double.parseDouble(text);
                        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                        boolean inserted = db.insertWeight(weight, date);
                        if (inserted) {
                            Toast.makeText(MainActivity.this, "Weight added", Toast.LENGTH_SHORT).show();
                            loadWeights();
                            checkGoalReached(weight);
                        } else {
                            Toast.makeText(MainActivity.this, "Error adding weight", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showUpdateWeightDialog() {
        final EditText input = new EditText(this);
        input.setHint("Enter new weight");

        new AlertDialog.Builder(this)
                .setTitle("Update Weight")
                .setView(input)
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String text = input.getText().toString().trim();
                        if (text.isEmpty()) {
                            Toast.makeText(MainActivity.this, "Weight required", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        double newWeight = Double.parseDouble(text);
                        String newDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                        boolean updated = db.updateWeight(selectedId, newWeight, newDate);
                        if (updated) {
                            Toast.makeText(MainActivity.this, "Updated", Toast.LENGTH_SHORT).show();
                            loadWeights();
                            checkGoalReached(newWeight);
                        } else {
                            Toast.makeText(MainActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSetGoalDialog() {
        final EditText input = new EditText(this);
        input.setHint("Enter goal weight");

        new AlertDialog.Builder(this)
                .setTitle("Set Goal Weight")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String text = input.getText().toString().trim();
                        if (text.isEmpty()) {
                            Toast.makeText(MainActivity.this, "Goal required", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        double goal = Double.parseDouble(text);
                        boolean saved = db.setGoalWeight(goal);
                        if (saved) {
                            Toast.makeText(MainActivity.this, "Goal saved", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Error saving goal", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void checkGoalReached(double currentWeight) {
        double goal = db.getGoalWeight();
        if (goal == -1) {
            return; // no goal set
        }

        // if current weight <= goal, goal reached
        if (currentWeight <= goal) {
            Toast.makeText(this, "Goal reached!", Toast.LENGTH_LONG).show();
            if (smsAllowed) {
                sendGoalSms();
            }
        }
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST);
        } else {
            smsAllowed = true;
        }
    }

    private void sendGoalSms() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(userPhoneNumber, null,
                    "Congratulations! You reached your goal weight!", null, null);
            Toast.makeText(this, "Goal SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                smsAllowed = true;
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                smsAllowed = false;
                Toast.makeText(this, "SMS permission denied. App will work without SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
